
// Data from BRAM to terminal

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <string.h>

int main()
{
	int fd, file,i,j, Status, data_trig, ord;
	int nev = 100;
	int int_trig =  0x41200000;

	int value = 0;
	unsigned page_addr, page_offset;
	void *ptr,*pt[5],*ptrt,*ptrt1;
	unsigned page_size=sysconf(_SC_PAGESIZE);
	page_offset = 16;
	FILE *fp, *fp1, *fp2;
	int nevt = 0;
	char c;

	/* Open /dev/mem file */
	fd = open ("/dev/mem", O_RDWR);

		/* mmap the device into memory */
		page_addr = (int_trig & (~(page_size-1)));
		page_offset = int_trig - page_addr;


		unsigned int bram[5];
		int w, ADC0A[5], ADC0B[5];
		bram[0] = 0x42000000;// ADC 1
		bram[1] = 0x44000000;// ADC 2
		bram[2] = 0x46000000;// ADC 3
		bram[3] = 0x48000000;// ADC 4
		bram[4] = 0x4A000000;// ADC 5


i=0;
//	  for(i=0;i<5;i++)
		  	  pt[i] = mmap(NULL, page_size*4, PROT_READ|PROT_WRITE, MAP_SHARED, fd, bram[i]);
 //     nevt++;


	  for(j=0; j<nev; j++)  //
	  {

		  ADC0A[i] = *((unsigned *)(pt[i] + page_offset));
		  ADC0B[i] =ADC0A[i]&0x1fff;
	//	  printf("%x - %x\n",ADC0A[i], page_offset);

		  printf  ("%d - adc0: %x" ,j, (ADC0A[i]>>16)&0x1fff);
		  printf(" - adc1: %x\n", ADC0B[i]);

		  page_offset=(page_offset+4)&0x3ffc;

/*
		  for (i =0; i<5; i++){
	    		ADC0A[i] = *((unsigned *)(pt[i] + page_offset));
	    		ADC0B[i] =ADC0A[i]&0x1fff;
		        printf  ("%d - adc%d: %d",j ,i*2, (ADC0A[i]>>16)&0x1fff);
		        printf(" - adc%d: %d",i*2+1, ADC0B[i]);

	           page_offset=(page_offset+4)&0x3ffc;
		  }
		  printf("\n");
*/



	  }






	    fclose(fd);

}



















/*
#include <stdio.h>

int main(){
	int i = 0;
	char line_buffer[BUFSIZ];
	char* words[20];
	FILE *fp = fopen("/srv/www/adc_data.json", "r" );

	while (fgets(line_buffer, sizeof(line_buffer), fp)) {
			words[i] = line_buffer;
			i = i + 1;
	}

	int j = rand()%8;
    int k = (j+1)%8;
    if (words[k] == "}") printf("/n");
    printf("%s ",  words[k]);
    fclose(fp);

}

*/

