 #define TESTAPP_GEN
 
 /******************************************************************************
 *
 * Copyright (C) 2005 - 2014 Xilinx, Inc.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Use of the Software is limited solely to applications:
 * (a) running on a Xilinx device, or
 * (b) that interact with a Xilinx device through a bus or interconnect.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * XILINX CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * Except as contained in this notice, the name of the Xilinx shall not be used
 * in advertising or otherwise to promote the sale, use or other dealings in
 * this Software without prior written authorization from Xilinx.
 *
 ******************************************************************************/
 /****************************************************************************/
 /**
 *
 * @file xuartlite_selftest_example.c
 *
 * This file contains a design example using the UartLite driver (XUartLite) and
 * hardware device.
 *
 * @note
 *
 * None
 *
 * MODIFICATION HISTORY:
 * <pre>
 * Ver   Who  Date    Changes
 * ----- ---- -------- -----------------------------------------------
 * 1.00a ecm  01/25/04 First Release.
 * 1.00a sv   06/13/05 Minor changes to comply to Doxygen and Coding guidelines
 * 2.00a ktn  10/20/09 Minor changes as per coding guidelines.
 * </pre>
 ******************************************************************************/
 
 /***************************** Include Files *********************************/
 
 #include "xparameters.h"
 #include "xuartlite.h"
 
 /************************** Constant Definitions *****************************/
 
 /*
  * The following constants map to the XPAR parameters created in the
  * xparameters.h file. They are defined here such that a user can easily
  * change all the needed parameters in one place.
  */
 #define UARTLITE_DEVICE_ID      XPAR_UARTLITE_0_DEVICE_ID
 
 int UartLiteSelfTestExample(u16 DeviceId);
 
 /************************** Variable Definitions *****************************/
 
 XUartLite UartLite;      /* Instance of the UartLite device */
 

 #ifndef TESTAPP_GEN
 int main(void)
 {
   int Status;
 
   // Run the UartLite self test example, specify the Device ID that is
   // generated in xparameters.h
   Status = UartLiteSelfTestExample(UARTLITE_DEVICE_ID);
   if (Status != XST_SUCCESS) { return XST_FAILURE; }
 
   return XST_SUCCESS;
 
 }
 #endif
 
 /*****************************************************************************/

 int UartLiteSelfTestExample(u16 DeviceId)
 {
   int Status;
 
   // Initialize the UartLite driver so that it is ready to use.
   Status = XUartLite_Initialize(&UartLite, DeviceId);
   if (Status != XST_SUCCESS) { return XST_FAILURE; }

   // Perform a self-test to ensure that the hardware was built correctly.
//   Status = XUartLite_SelfTest(&UartLite);
//   if (Status != XST_SUCCESS) { return XST_FAILURE; }
 
   return XST_SUCCESS;
 }
 
 
